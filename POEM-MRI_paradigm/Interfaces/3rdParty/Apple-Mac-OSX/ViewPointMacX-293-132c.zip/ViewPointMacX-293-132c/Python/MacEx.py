#!/usr/bin/python
#
# ViewPoint EyeTracker (R) interface to Mac Python
#       Verify the sections below marked:       # <<<< CHANGE AS NEEDED
#	This demo prints the (x,y) GazePoint every second.
#

#
#  -------- Imports  -------- 
#
from ctypes import *
import os
import time

#
#  -------- Constants (see file vpx.h for full listing)  -------- 
#
VPX_STATUS_ViewPointIsRunning = 1
EYE_A = 0
EYE_B = 1
VPX_DAT_FRESH = 2

#
#  -------- Load the Mac ViewPoint dynamic library and initialize it  -------- 
#

vpxDll = "/usr/local/lib/libvpx_interapp.dylib"	# <<<< CHANGE AS NEEDED
if ( not os.access(vpxDll,os.F_OK) ):
	print("WARNING: Invalid vpxDll path; you need to edit the .py file")
cdll.LoadLibrary( vpxDll )
vpx = CDLL( vpxDll )
initializeResult = vpx.VPX_so_init()
if ( initializeResult == 0 ):
	print("Successfully initialized dylib.")
else:
	print("There was a problem initializing the Mac ViewPoint dynamic library")

#
#  -------- Make Ethernet connection to the ViewPoint EyeTracker  -------- 
#

connectResult = vpx.VPX_ConnectToViewPoint( '192.168.1.79'.encode('ascii'), 5000 )	 # <<<< CHANGE AS NEEDED
if ( connectResult == 0 ):
	print("Successfully  connected to ViewPoint.")
else:
	print("There was a problem making an Ethernet connection to ViewPoint")

vpx.VPX_SendCommand('say "Hello from Mac Python" '.encode('ascii'))

#
#  -------- Create needed structures for variables  -------- 
#
class RealPoint(Structure):
	_fields_ = [("x",c_float),("y",c_float)]

VPX_funcRealPoint2 = CFUNCTYPE( c_int, c_int, POINTER(RealPoint) )

#
vpxGetGazePoint2 = VPX_funcRealPoint2( vpx.VPX_GetGazePointCorrected2 )

	# Need to declare a RealPoint variable
gpA = RealPoint(1.1,1.1)

#
#  -------- Loop  -------- 
#			?? For some reason, methods appear to return 0 the first time they are called.
#
print( "ViewPoint running: ", vpx.VPX_GetStatus(VPX_STATUS_ViewPointIsRunning) )

for x in range(0, 7):
        vpxGetGazePoint2( EYE_A, gpA )
        print( gpA.x, gpA.y )
        time.sleep(1)
