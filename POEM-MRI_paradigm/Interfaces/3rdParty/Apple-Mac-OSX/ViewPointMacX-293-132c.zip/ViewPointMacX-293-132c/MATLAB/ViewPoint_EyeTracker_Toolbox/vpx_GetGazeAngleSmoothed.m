function [xangle, yangle]=vpx_GetGazeAngleSmoothed(eyetype)
%----------------------------------------------------------------------
%% vpx_GetGazeAngleSmoothed
%
%   Retrieves the gaze angle
%
%   USAGE: [xangle,yangle]=vpx_GetGazeAngleSmoothed(eyetype);
%   INPUT: eyetype (0 for Eye_A and 1 for Eye_B)
%   OUTPUT: x and y gazeangle.
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
 vpxrealpoint=struct('x',0,'y',0);
 vpstruct = libstruct('VPX_RealPoint', vpxrealpoint);
 if(nargin<1)
     [null,gazeangle]=calllib('vpx','VPX_GetGazeAngleSmoothed2',0,vpstruct);
 elseif(nargin==1)
     [null,gazeangle]=calllib('vpx','VPX_GetGazeAngleSmoothed2',eyetype,vpstruct);
 end
 xangle=gazeangle.x;
 yangle=gazeangle.y;