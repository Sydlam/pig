function [posangle]=vpx_GetHeadPositionAngle() 
%----------------------------------------------------------------------
%% vpx_GetHeadPositionAngle
%
%    retrieves the sixDOF (x,y,z,roll,pitch,yaw) from a headtracker.
%
%   USAGE: [sixDOF]=vpx_GetHeadPositionAngle();
%   INPUT: eyetype (0 for Eye_A and 1 for Eye_B)
%   OUTPUT: x and y gazeangle.
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
 vpxpositionangle=struct('x',0,'y',0,'z',0,'roll',0,'pitch',0,'yaw',0);
 vpstruct = libstruct('VPX_PositionAngle', vpxpositionangle);
 [null,posangle]=calllib('vpx','VPX_GetHeadPositionAngle',vpstruct);
 x=posangle.x;
 y=posangle.y;
 z=posangle.z;
 roll=posangle.roll;
 pitch=posangle.pitch;
 yaw=posangle.yaw;