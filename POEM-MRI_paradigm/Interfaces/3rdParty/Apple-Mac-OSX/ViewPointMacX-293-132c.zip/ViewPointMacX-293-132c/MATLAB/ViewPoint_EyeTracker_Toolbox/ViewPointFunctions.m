%%  ViewPoint EyeTracker Toolbox (TM) Functions
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%	All rights reserved.
%------------------------------------------------------

%more on

disp('-------------------------------------------------------------------')
disp('LIST OF FUNCTIONS AVAILABLE - ');
disp(' To know more about a function type: help functionname ')
disp('-------------------------------------------------------------------')
disp('vpx_Trademark')
disp('vpx_Initialize')
disp('vpx_Unload')
disp('vpx_ConnectToViewPoint (MAC only)')
disp('vpx_DisconnectFromViewPoint (MAC only)')
disp('vpx_GetDllVersion')
disp('vpx_SendCommandString')
disp('vpx_GetStatus')
disp('--------')
disp('vpx_GetGazePoint')
disp('vpx_GetGazePointSmoothed')
disp('vpx_GetGazeAngle')
disp('vpx_GetGazeAngleSmoothed')
disp('vpx_GetDataQuality')
disp('vpx_GetPupilPoint')
disp('vpx_GetGlintPoint')
disp('vpx_GetDiffVector')
disp('vpx_GetDataTime')
disp('vpx_GetDataDeltaTime')
disp('vpx_GetPupilSize')
disp('vpx_GetPupilAspectRatio')
disp('vpx_GetFixationSeconds')
disp('vpx_GetDrift')
disp('vpx_GetTotalVelocity')
disp('vpx_GetComponentVelocity')
disp('vpx_GetTorsion')
disp('vpx_GetROI_RealRect')
disp('vpx_ROI_GetHitListLength')
disp('vpx_ROI_GetHitListItem')
disp('vpx_ROI_MakeHitListString (PC only)')
disp('--------')
disp('vpx_GetCalibrationStimulusPoint')
disp('--------')
disp('vpx_GazeMovement')
disp('vpx_Calibrate')
disp('vpx_GeometryGrid')
disp('--------')
disp('vpx_GetHeadPositionAngle')
disp('VPX_Matlab_Demo')
disp('ViewPointFunctions')
disp('-------------------END---------------------------------------------')
%more off

 