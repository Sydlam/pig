function [Torsion]=vpx_GetTorsion(eyetype)
%----------------------------------------------------------------------
%% vpx_GetTorsion
%
%   Torsion is in degrees, so the value may be 2.25 degrees rotation.
%
%   USAGE: [Torsion]=vpx_GetTorsion() OR vpx_GetTorsion(eyetype);
%   INPUT: none or eyetype (0 for Eye_A and 1 for Eye_B)
%   OUTPUT: Torsion
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
 Torsionvalue=double(0);  
 if(nargin<1)
 [null,Torsion]=calllib('vpx','VPX_GetTorsion',Torsionvalue);
 elseif(nargin==1)
      [eye,null,Torsion]=calllib('vpx','VPX_GetTorsion2',eyetype,Torsionvalue);
 end
