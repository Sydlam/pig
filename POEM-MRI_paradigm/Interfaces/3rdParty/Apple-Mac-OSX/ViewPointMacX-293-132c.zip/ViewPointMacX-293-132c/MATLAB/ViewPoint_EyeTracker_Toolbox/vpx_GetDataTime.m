function [datatime]=vpx_GetDataTime(eyetype) 
%----------------------------------------------------------------------
%% vpx_GetDataTime
%
%   video sych time this better reflects the actual time that the image
%   of the eye became available, and is not affected by variance in 
%   image processing time
%
%   USAGE: [datatime]=vpx_GetDataTime();
%   INPUT: eyetype (0 for Eye_A and 1 for Eye_B)
%   OUTPUT: datatime
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
 timevalue=double(0);
 if(nargin<1)
     eyetype=0
 [null,datatime]=calllib('vpx','VPX_GetDataTime2',eyetype,timevalue);
 elseif(nargin==1)
     [null,datatime]=calllib('vpx','VPX_GetDataTime2',eyetype,timevalue);
 end
