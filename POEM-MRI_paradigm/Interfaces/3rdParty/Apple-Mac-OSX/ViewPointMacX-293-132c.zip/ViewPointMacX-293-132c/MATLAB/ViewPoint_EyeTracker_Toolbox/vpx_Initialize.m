function r = vpx_Initialize( vpxDylib, vpxToolbox, vpxH )
%------------------------------------------------------
%% vpx_Initialize
%   
%	Loads the dynamically linked library into Matlab.
%
%   USAGE 
%		vpx_Initialize
%
%   IMPORTANT: 
%		You must specify the the full path file name for:
%				vpxDylib
%				vpxToolbox
%				vpxH
%		Note the paths should be within single quotes.
%
%   USAGE: vpx_Initialize( vpxDylib, vpxToolbox, vpxH )
%   
%   Example code:
%		vpxDylib    = '/usr/local/lib/libvpx_interapp.dylib'
%		vpxToolbox  = 'Users/karl/ARI/SDK/vpxtoolbox.h'
%		vpxH  	    = 'Users/karl/ARI/SDK/vpx.h'
%		vpx_Initialize( vpxDylib, vpxToolbox, vpxH )
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2015, Arrington Research, Inc.
%   All rights reserved.
%------------------------------------------------------
if( libisloaded('vpx') == 0 )

  if( nargin < 1 )
    vpxDylib   = '/usr/local/lib/libvpx_interapp.dylib'
    vpxToolbox = '/Users/karl/ARI/Test/SDK/vpxtoolbox.h';
    [notfound,warnings]=loadlibrary( vpxDylib, vpxToolbox, 'addheader', 'vpx.h', 'alias', 'vpx' );
  elseif( nargin == 3 )
    loadlibrary( vpxDylib, vpxToolbox, 'addheader', 'vpx.h', 'alias', 'vpx' );
  end

  calllib('vpx','VPX_so_init');

  warning('off','MATLAB:dispatcher:InexactMatch')

end