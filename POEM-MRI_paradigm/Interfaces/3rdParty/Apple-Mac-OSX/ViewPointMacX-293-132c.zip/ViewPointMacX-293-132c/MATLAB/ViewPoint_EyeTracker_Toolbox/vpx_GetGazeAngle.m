function [xangle, yangle]=vpx_GetGazeAngle(eyetype)
%----------------------------------------------------------------------
%% vpx_GetGazeAngle
%   Retrieves the gaze angle in degrees
%
%   USAGE: [xangle,yangle]=vpx_GetGazeAngle(eyetype);
%   	where 
%           eyeID : 0 for Eye_A, or 1 for Eye_B
%           
%   OUTPUT: 
%       x and y are the gaze angle in degrees.
%
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%	All rights reserved.
%----------------------------------------------------------------------
 vpxrealpoint=struct('x',0,'y',0);
 vpstruct = libstruct('VPX_RealPoint', vpxrealpoint);
 if(nargin<1)
     eyetype=0;
 [null,gazeangle]=calllib('vpx','VPX_GetGazeAngle2',eyetype,vpstruct);
 elseif(nargin==1)
 [null,gazeangle]=calllib('vpx','VPX_GetGazeAngle2',eyetype,vpstruct);
 end
 xangle=gazeangle.x;
 yangle=gazeangle.y;