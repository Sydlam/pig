%%  ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%------------------------------------------------------
disp('-------------------------------------------------------------------')
disp('ViewPoint EyeTracker Toolbox (TM)')
disp('Copyright 2005-2010, Arrington Research, Inc.')
disp('All rights reserved.')
disp('-------------------------------------------------------------------')
