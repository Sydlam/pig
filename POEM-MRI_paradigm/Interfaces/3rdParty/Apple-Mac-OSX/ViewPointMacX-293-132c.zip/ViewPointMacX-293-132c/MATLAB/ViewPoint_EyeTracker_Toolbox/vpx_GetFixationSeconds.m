function [fixationsec]=vpx_GetFixationSeconds(eyetype)
%----------------------------------------------------------------------
%% vpx_GetFixationSeconds
%
%   vpx_GetFixationSeconds retrieves the number of seconds
%	 that the total velocity has been below the VelocityCriterion and
%	 the gaze drift has been below the DriftCriterion.
%	 A zero value indicates a saccade is occurring.
%	 Note, use with:
%			vpx_SendCommandString( "velocityCriterion 0.3");
%	 		vpx_SendCommandString( "driftCriterion 0.1");
%
%   USAGE: [fixationsec]=vpx_GetFixationSeconds(eyetype);
%   INPUT: eyetype (0 for Eye_A and 1 for Eye_B)
%   OUTPUT: fixationsec
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
 timevalue=double(0);  
 if(nargin<1)
     eyetype=0;
      [null,fixationsec]=calllib('vpx','VPX_GetFixationSeconds2',eyetype,timevalue);
 elseif(nargin==1)
 [null,fixationsec]=calllib('vpx','VPX_GetFixationSeconds2',eyetype,timevalue);
 end
