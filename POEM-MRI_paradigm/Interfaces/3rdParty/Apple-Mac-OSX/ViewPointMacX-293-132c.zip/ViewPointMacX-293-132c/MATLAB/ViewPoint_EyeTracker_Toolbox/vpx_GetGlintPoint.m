function [xposition, yposition]=vpx_GetGlintPoint(eyetype)
%----------------------------------------------------------------------
%% vpx_GetGlintPoint
%
%   retrieves the normalized (x,y) location of the 
%	center of the glint (center of the oval fit to the glint) in the
%	EyeSpace.
%
%   USAGE: [x,y]=vpx_GetGlintPoint() or vpx_GetGlintPoint(eyetype);
%   INPUT: No arguments OR eyetype (0 for Eye_A and 1 for Eye_B)
%   OUTPUT: x and y position of glint.
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
  vpxrealpoint=struct('x',0,'y',0); 
 vpstruct = libstruct('VPX_RealPoint', vpxrealpoint);
 if(nargin<1)
 [null,GlintPoint]=calllib('vpx','VPX_GetGlintPoint',vpstruct);
 elseif(nargin==1)
     [null,GlintPoint]=calllib('vpx','VPX_GetGlintPoint2',eyetype,vpstruct);
 end
 xposition=GlintPoint.x;
 yposition=GlintPoint.y;