function [DataQuality]=vpx_GetDataQuality(eyetype)
%----------------------------------------------------------------------
%vpx_GetDataQuality2
%   vpx_GetDataQuality2 retrieves a code indicating what, if any, errors
%	 occurred during image processing and during testing against various
%	 data criteria levels.  
%
%   USAGE: [DataQuality]=vpx_GetDataQuality2(eyetype);
%   INPUT: eyetype (0 for Eye_A and 1 for Eye_B)
%   OUTPUT: DataQuality
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
 DataQualityvalue=0; 
 if(nargin<1)
      [null,DataQuality]=calllib('vpx','VPX_GetDataQuality2',0,DataQualityvalue);
 elseif(nargin==1)
 [null,DataQuality]=calllib('vpx','VPX_GetDataQuality2',eyetype,DataQualityvalue);
 end