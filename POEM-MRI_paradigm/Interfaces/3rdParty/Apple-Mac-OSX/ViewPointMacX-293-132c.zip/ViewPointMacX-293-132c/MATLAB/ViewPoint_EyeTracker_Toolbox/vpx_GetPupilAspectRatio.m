function [PupilAspectRatio]=vpx_GetPupilAspectRatio(eyetype)
%----------------------------------------------------------------------
%% vpx_GetPupilAspectRatio
%
%   vpx_GetPupilAspectRatio is independent of the EyeCamera window shape.
%      aspect ratio, so a circular pupil will always produce a value of 1.0
%
%   USAGE: [arout]=vpx_GetPupilAspectRatio() OR vpx_GetPupilAspectRatio(eyetype);
%   INPUT: No arguments OR eyetype
%   OUTPUT:arout (pupil aspect ratio).
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
aspectratio = double(0);
if(nargin<1)
[null,PupilAspectRatio]=calllib('vpx','VPX_GetPupilAspectRatio',aspectratio);
elseif(nargin==1)
  [null,PupilAspectRatio]=calllib('vpx','VPX_GetPupilAspectRatio2',eyetype,aspectratio); 
end

