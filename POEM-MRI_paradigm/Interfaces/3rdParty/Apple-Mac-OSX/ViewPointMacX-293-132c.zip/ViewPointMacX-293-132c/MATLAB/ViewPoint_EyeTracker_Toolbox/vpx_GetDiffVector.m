function [xDiffVector, yDiffVector]=vpx_GetDiffVector(eyetype)
%----------------------------------------------------------------------
%% vpx_GetDiffVector
%
%   vpx_GetDiffVector retrieves the normalized vector difference between
%   the centers of the pupil and the glint in the EyeSpace.
%
%   USAGE: [xDiffVector,yDiffVector]=vpx_GetDiffVector(eyetype);
%   INPUT: No arguments or eyetype (0 for Eye_A and 1 for Eye_B)
%   OUTPUT: xDiffVector,yDiffVector.
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
 vpxrealpoint=struct('x',0,'y',0); 
 vpstruct = libstruct('VPX_RealPoint', vpxrealpoint);
 if(nargin<1)
 [null,DiffVector]=calllib('vpx','VPX_GetDiffVector',vpstruct);
 elseif(nargin==1)
     [null,DiffVector]=calllib('vpx','VPX_GetDiffVector2',eyetype,vpstruct);
 end
 xDiffVector=DiffVector.x;
 yDiffVector=DiffVector.y;