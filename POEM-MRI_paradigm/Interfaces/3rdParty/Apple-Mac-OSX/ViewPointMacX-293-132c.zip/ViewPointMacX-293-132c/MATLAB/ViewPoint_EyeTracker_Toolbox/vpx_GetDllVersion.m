function dllversion = VPX_GetDllVersion() 
%----------------------------------------------------------------------
%% vpx_GetDllVersion
%
%   Retrieves the dynamic library (DLL or dylib) version.
%
%   USAGE: dllversion = VPX_GetDllVersion()
%   INPUT: none
%   OUTPUT: dllversion
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
dllversion=calllib('vpx','VPX_GetDLLVersion');

