function [deltadatatime]=vpx_GetDataDeltaTime(eyetype)
%----------------------------------------------------------------------
%% vpx_GetDataDeltaTime
%
%   The precision time value difference between current and previous
%   VPX_GetDataTime values.
%   NOTE: This is affected by a change in VPX_GetDataTime such that 
%   the variance of the delta times should be much less.
%
%   USAGE: [datatime]=vpx_GetDataDeltaTime(eyetype);
%   INPUT: eyetype (0 for Eye_A and 1 for Eye_B)
%   OUTPUT: deltadatatime
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
 timevalue=double(0);
 if(nargin<1)
     eyetype=0;
 [null,deltadatatime]=calllib('vpx','VPX_GetDataDeltaTime2',eyetype,timevalue);
 elseif(nargin==1)
      [null,deltadatatime]=calllib('vpx','VPX_GetDataDeltaTime2',eyetype,timevalue);
 end
