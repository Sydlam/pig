%----------------------------------------------------------------------
%% vpx_GetCalibrationStimulusPoint
%
%   calPt is the (x,y) coordinate in normalized (0.0 .. 1.0) form.
%
%   USAGE: [xstimpoint, ystimpoint]=vpx_GetCalibrationStimulusPoint(ixPt)
%   INPUT: ixPt(any value 1 and 72)
%   OUTPUT: xstimpoint and y stimpoint
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
function [xstimpoint, ystimpoint]=vpx_GetCalibrationStimulusPoint(ixPt)

 vpxrealpoint=struct('x',0,'y',0);
 vpstruct = libstruct('VPX_RealPoint', vpxrealpoint);
 [null,stimpoint]=calllib('vpx','VPX_GetCalibrationStimulusPoint',ixPt,vpstruct);
 xstimpoint=stimpoint.x;
 ystimpoint=stimpoint.y; 