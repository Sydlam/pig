function [RealRect]=vpx_GetROI_RealRect(roi) 
%----------------------------------------------------------------------
%% vpx_GetROI_RealRect  *** DEPRECATED ***
%
%   vpx_GetROI_RealRect gets the coordinates of the given ROI
%
%   USAGE: [RealRect]=vpx_GetROI_RealRect(roi);
%   INPUT: roi (region of interest)
%   OUTPUT: RealRect.top, RealRect.left, RealRect.right, RealRect.bottom,
%           (coordinates of the reactangle)
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
 vpxRealRect=struct('left',0,'top',0,'right',0,'bottom',0);
 vpstruct = libstruct('VPX_RealRect', vpxRealRect);
 [null,RealRect]=calllib('vpx','VPX_GetROI_RealRect',roi,vpstruct);
