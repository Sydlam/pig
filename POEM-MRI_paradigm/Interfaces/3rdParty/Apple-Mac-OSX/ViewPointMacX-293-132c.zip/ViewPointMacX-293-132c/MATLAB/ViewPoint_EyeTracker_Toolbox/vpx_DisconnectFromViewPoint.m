function r = vpx_DisconnectFromViewPoint();
%-------------------------------------------------------
% vpx_DisconnectFromViewPoint
%
%  Disconnect socket connection to the server built into ViewPoint.
%
%   USAGE: 
%       r = vpx_DisconnectFromViewPoint
%
%   INPUT: 
%		none
%
%   OUTPUT: 
%		Return values:	 1 - already disconnected
%				 0 - disconnect success
%				-1 - diconnect error
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%--------------------------------------------------------
r = calllib('vpx', 'VPX_DisconnectFromViewPoint');
