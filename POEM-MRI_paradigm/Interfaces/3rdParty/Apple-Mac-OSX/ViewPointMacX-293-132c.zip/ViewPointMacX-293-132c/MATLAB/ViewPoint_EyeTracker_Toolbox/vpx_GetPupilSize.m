function [xsize,ysize]=vpx_GetPupilSize(eyetype)
%----------------------------------------------------------------------
%% vpx_GetPupilSize
%
%   vpx_GetPupilSize retrieves the size of the oval fit to the pupil
%	in the EyeSpace window.  NOTE: The x- y-size values are normalized
%	with respect to the EyeSpace dimensions that have a 4:3 aspect, so
%	the x- and y-values are anisotropic.  To obtain the aspect ratio of
%	the pupil, rescale by:  ( aspect = ps.x / ( ps.y * 0.75 ) ).
%
%   USAGE: [xsize,ysize]=vpx_GetPupilSize() OR vpx_GetPupilSize(eyetype);
%   INPUT: No arguments or eyetype  (0 for Eye_A and 1 for Eye_B)
%   OUTPUT: x and y sizes of the pupil.
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
 vpxrealpoint=struct('x',0,'y',0);
   vpstruct = libstruct('VPX_RealPoint', vpxrealpoint); 
 if (nargin<1) 
 [null,pupilsize]=calllib('vpx','VPX_GetPupilSize',vpstruct);
 elseif (nargin==1)
 [null,pupilsize]=calllib('vpx','VPX_GetPupilSize2',eyetype,vpstruct);
 end
 xsize=pupilsize.x;
 ysize=pupilsize.y;