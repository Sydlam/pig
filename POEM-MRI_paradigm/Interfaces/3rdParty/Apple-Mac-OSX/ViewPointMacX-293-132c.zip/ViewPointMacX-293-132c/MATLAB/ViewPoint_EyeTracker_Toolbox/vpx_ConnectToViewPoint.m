function r = vpx_ConnectToViewPoint( str, portNumber )
%-------------------------------------------------------
%vpx_ConnectToViewPoint
%
%  Creates a socket connection to the server built into ViewPoint.
%
%   USAGE: 
%       r = vpx_ConnectToViewPoint( ipAddress, portNumber );
%
%   INPUT: 
%		ipAddress	dot quad string, eg: "192.168.1.4"
%		portNumber	unsigned integer, 5000 by default
%
%   OUTPUT: 
%		Return values:	 1 - already connected
%				 0 - connect success
%				-1 - connect error
%				-2 - negotiation send error
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%--------------------------------------------------------
r = calllib('vpx', 'VPX_ConnectToViewPoint',str,portNumber);
end
