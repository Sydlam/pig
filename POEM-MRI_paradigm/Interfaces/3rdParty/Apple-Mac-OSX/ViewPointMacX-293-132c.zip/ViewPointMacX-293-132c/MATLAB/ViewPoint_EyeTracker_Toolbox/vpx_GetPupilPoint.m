function [xposition, yposition]=vpx_GetPupilPoint(eyetype)
%----------------------------------------------------------------------
%% vpx_GetPupilPoint
%
%    vpx_GetPupilPoint retrieves the normalized (x,y) location of the 
%	 center of the pupil (center of the oval fit to the pupil) in the
%	 EyeSpace.
%
%   USAGE: [xposition,yposition]=vpx_GetPupilPoint() or vpx_GetPupilPoint2(eyetype);
%   INPUT: No arguments OR eyetype (0 for Eye_A and 1 for Eye_B)
%   OUTPUT: x and y position of pupil.
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
 vpxrealpoint=struct('x',0,'y',0);
 vpstruct = libstruct('VPX_RealPoint', vpxrealpoint);
 if(nargin<1)
 [null,pupilPoint]=calllib('vpx','VPX_GetPupilPoint',vpstruct);
 elseif(nargin==1)
 [null,pupilPoint]=calllib('vpx','VPX_GetPupilPoint2',eyetype,vpstruct);
 end
 xposition=pupilPoint.x;
 yposition=pupilPoint.y;