function [TotalVelocity]=vpx_GetTotalVelocity(eyetype)
%----------------------------------------------------------------------
%% vpx_GetTotalVelocity
%
%    vpx_GetTotalVelocity retrieves the total velocity of
%	 movement in the (x,y) plane.  That is, the first derivative
%	 of the (smoothed) calculated position of gaze.
%
%   USAGE: 
%       totalVelocity = vpx_GetTotalVelocity
%       totalVelocity = vpx_GetTotalVelocity2( eyetype );
%   INPUT: 
%       none or eyetype (0 for Eye_A and 1 for Eye_B)
%   OUTPUT: 
%       totalVelocity
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
 TotalVelocityvalue=double(0); 
 if(nargin<1)
 [null,TotalVelocity]=calllib('vpx','VPX_GetTotalVelocity',TotalVelocityvalue);
 elseif(nargin==1)
     [null,TotalVelocity]=calllib('vpx','VPX_GetTotalVelocity2',eyetype,TotalVelocityvalue);
 end
