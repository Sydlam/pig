function [x,y]=vpx_GetComponentVelocity(eyetype)
%----------------------------------------------------------------------
%% vpx_GetComponentVelocity
%     vpx_GetComponentVelocity retrieves the x- and y-components
%     of the eye movement velocity.
%
%   USAGE: [x,y]=vpx_GetComponentVelocity() OR vpx_GetComponentVelocity(eyetype);
%   INPUT: none OR eyetype (0 for Eye_A and 1 for Eye_B)
%   OUTPUT: x,y
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
 vpxrealpoint=struct('x',0,'y',0);  
 ComponentVelocityvalue = libstruct('VPX_RealPoint', vpxrealpoint);
 if(nargin<1)
 [null,ComponentVelocity]=calllib('vpx','VPX_GetComponentVelocity',ComponentVelocityvalue);
 elseif(nargin==1)
      [eye,null,ComponentVelocity]=calllib('vpx','VPX_GetComponentVelocity2',eyetype,ComponentVelocityvalue);
 end 
x=ComponentVelocity.x;
y=ComponentVelocity.y;