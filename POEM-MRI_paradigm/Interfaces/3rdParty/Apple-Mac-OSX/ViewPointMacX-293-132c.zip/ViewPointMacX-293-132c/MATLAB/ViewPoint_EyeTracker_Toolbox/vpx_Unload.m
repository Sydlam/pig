function r = vpx_Unload()
%------------------------------------------------------
%% vpx_Unload
%
%   This function unloads the dynamic library
%   Input : no arguments
%   Its always better to unload before quitting matlab
%   
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%------------------------------------------------------
if(libisloaded('vpx'))
    unloadlibrary('vpx');
end