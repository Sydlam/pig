function [HitListLength]=vpx_ROI_GetHitListLength(eyetype)
%----------------------------------------------------------------------
%% vpx_GetHitListLength
%
%    returns a the number of ROI that are currently active; since ROI
%	 can be overlapped, so more than one can be active at the same time.
%	 This value is NOT cumulative over time.
%
%   USAGE: [HitListLength]=vpx_GetHitListLength2(eyetype);
%   INPUT: eyetype (0 for Eye_A and 1 for Eye_B)
%   OUTPUT: HitListLength
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
 
 [HitListLength]=calllib('vpx','VPX_ROI_GetHitListLength',eyetype);
  