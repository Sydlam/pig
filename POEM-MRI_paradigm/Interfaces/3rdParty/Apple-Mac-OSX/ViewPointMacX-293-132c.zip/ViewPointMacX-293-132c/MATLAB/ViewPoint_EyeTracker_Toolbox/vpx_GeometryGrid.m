function vpx_GeometryGrid( ntimeseconds )
%--------------------------------------------------------------------------
%% vpx_GeometryGrid
%   
%    This function displays two thick white lines one horizontal and
%    one vertical in the stimulus window.
%    Viewing distance can be adjusted by using the option provided in Viewpoint
%    The adjustment can be done as follows:
%           From the 'stimuli' menu in ViewPoint select 'Geometry setup'.
%    The Geometry setup window will be displayed, the sliders can be
%    adjusted to indicate:
%    a. viewing distance from the subjects eye to the center of the display screen
%    b. length of horizontal and vertical lines.
%
%    USAGE: vpx_GeometryGrid(ntimeseconds)
%    INPUT: ntimeseconds - if not specified, defaults to 240 seconds.
%    
%    TO HALT/EXIT THE PROGRAM(From PsychToolbox)
%     Bring forward matlab command window and press Ctrl-C. This halts the program. 
%       (Type a "c" while holding down the "Ctrl"
%   	key.)  To halt a runaway Psychtoolbox script in
%   	Win Psychtoolbox you might resort to the Windows Task Manager to kill
%   	the Matlab process.  (Use Ctrl-Alt-Delete to open a window from which
%   	you can start the Task Manager.)
%    
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%--------------------------------------------------------------------------

if(nargin==0)
    ntimeseconds=240;
end
ntimeseconds = abs(ntimeseconds);

whichscreen=0;
[window,screensize]=screen(whichscreen,'OpenWindow',[0 0 0]);
marginX=screensize(3)/10;
marginY=screensize(4)/10;
lengthX=screensize(3)-(2*marginX);
lengthY=screensize(4)-(2*marginY);
midpointX=screensize(3)/2;
midpointY=screensize(4)/2;
screen(window,'DrawLine',[255 255 255], marginX,midpointY,(marginX+lengthX),midpointY,4);
screen(window,'DrawLine',[255 255 255], midpointX,marginY,midpointX,(marginY+lengthY),4);
screen(window,'Flip');

WaitSecs(ntimeseconds);
screen(window,'Close');