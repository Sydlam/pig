function statusResult = vpx_GetStatus(statusItem)
%--------------------------------------------------------------------------
%% vpx_GetStatus
%     This provides a simple way to determine the current status or state 
%     of various ViewPoint operations.
%
%   USAGE: 
%       statusResult = vpx_GetStatus( statusItem )
%           where statusItem is an integer 
%           enumeration code that is defined in vpx.h
%
%        statusItem      enumItem                    statusResult
%        ----------   -------------------------      ------------
%
%           1   VPX_STATUS_ViewPointIsRunning           BOOL	
%           2   VPX_STATUS_VideoIsFrozen                BOOL
%           3   VPX_STATUS_DataFileIsOpen		        BOOL
%           4   VPX_STATUS_DataFileIsPaused	            BOOL
%           5   VPX_STATUS_AutoThresholdInProgress      BOOL
%           6   VPX_STATUS_CalibrationInProgress        BOOL
%           7   VPX_STATUS_StimulusImageShape           shapeCode
%           8   VPX_STATUS_BinocularModeActive          BOOL
%           9   VPX_STATUS_SceneVideoActive             BOOL
%           10  VPX_STATUS_DistributorAttached          distrubutorCode
%
%    shapeCode:'I'=isotropic stretch, 'C'=centered, 'F'=fit, 'A'=actual
%    distrubutorCode: 1=ViewPoint, 2=RemoteLink, 3=EthernetClient 
%    
%   RESULT:
%       Status result depends upon 
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
% -------------------------------------------------------------------------
   statusResult=calllib('vpx','VPX_GetStatus',statusItem); 
    