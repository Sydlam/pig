function varargout = VPX_Matlab_Demo(varargin)
%--------------------------------------------------------------------------
%% VPX_Matlab_Demo
%
%      VPX_Matlab_Demo, by itself, creates a new VPX_Matlab_Demo 
%      or raises the existing singleton*.
%
%      H = VPX_Matlab_Demo returns the handle to a new VPX_Matlab_Demo 
%      or the handle to the existing singleton*.
%
%      VPX_Matlab_Demo('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in VPX_Matlab_Demo.M with the given input arguments.
%
%      VPX_Matlab_Demo('Property','Value',...) creates a new VPX_Matlab_Demo or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before VPX_Matlab_Demo_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to VPX_Matlab_Demo_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
%       VPX_Matlab_Demo M-file for VPX_Matlab_Demo.fig
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% Edit the above text to modify the response to help VPX_Matlab_Demo
%
% Last Modified by GUIDE v2.5 01-Apr-2010 14:35:51
%
% Begin initialization code - DO NOT EDIT
%--------------------------------------------------------------------------
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @VPX_Matlab_Demo_OpeningFcn, ...
                   'gui_OutputFcn',  @VPX_Matlab_Demo_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before VPX_Matlab_Demo is made visible.
function VPX_Matlab_Demo_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to VPX_Matlab_Demo (see VARARGIN)

global openingFcn
openingFcn = 0;

% Choose default command line output for VPX_Matlab_Demo
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
%Initializing the DLL
%loadlibrary('VPX_Interapp.dll','VPX.h','alias','vpx');

time=1:50;
yposition=zeros(1,50);
xposition=zeros(1,50);
axes(handles.plottest);
h=gca;
hLine=plot(time,yposition);ylim([0 1]);

stripchart('Initialize',h)
axes(handles.plottest2);
h1=gca;
hLine1=plot(time,yposition);ylim([0 1]);

stripchart('Initialize',h1)

axes(handles.plt_gaze_space);

global eye
eye = 0;

global flag
flag = 0;

i=1;
while(flag~=1)

 %Get the gaze point from ViewPoint.
 gazePoint=struct('x',0.5,'y',0.5); 
 [gazePoint.x,gazePoint.y]=vpx_GetGazePointSmoothed(eye);
 
 %Add the gaze point to the strip charts.
 xposition(i)=gazePoint.x;
 yposition(i)=gazePoint.y;
 stripchart('Update',hLine1,xposition(i));
 stripchart('Update',hLine,yposition(i));

 %Set the gaze point on the gaze plot.
 plot(xposition(i),yposition(i),'*');
 xlim([0 1])
 ylim([0 1])

 %Set the gaze point in the edit boxes.
 set(handles.edt_x_gaze,'String',xposition(i));
 set(handles.edt_y_gaze,'String',yposition(i));

 %Get and set the pupil aspect ratio.
 [pupilaspectratio]=vpx_GetPupilAspectRatio(eye);
 set(handles.edt_pupil_aspect_ratio,'String',pupilaspectratio);

 %Get and set the pupil size.
 pupilsize=struct('x',0.5,'y',0.5); 
 [pupilsize.x,pupilsize.y]=vpx_GetPupilSize(eye);
 set(handles.edt_pupil_width,'String',pupilsize.x);
 set(handles.edt_pupil_height,'String',pupilsize.y); 
 
 %Index the loop var.
 i=i+1;

 %We made it.
 openingFcn = 1;

end

% Delete the object (close the figure) here so we don't access anything in the while loop that
% has been deleted.  The exit for the while loop is set in
% figure1_CloseRequestFcn
delete(hObject);


% --- Outputs from this function are returned to the command line.
function varargout = VPX_Matlab_Demo_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Get default command line output from handles structure

global flag
if(flag==0)
    varargout{1} = handles.output;
end


% % --- Executes on button press in InitializeDll.
% function InitializeDll_Callback(hObject, eventdata, handles)
% % hObject    handle to InitializeDll (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% % loadlibrary('VPX_Interapp.dll','VPX.h','alias','vpx');
% % msgbox('The DLL has been successfully loaded')
% 
% % --- Executes on button press in UnloadDll.
% function UnloadDll_Callback(hObject, eventdata, handles)
% % hObject    handle to UnloadDll (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% unloadlibrary('vpx');
% msgbox('The Library has been successfully unloaded');

% --- Executes on button press in VPX_SendCommandString.
function VPX_SendCommandString_Callback(hObject, eventdata, handles)
% hObject    handle to VPX_SendCommandString (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
str=get(handles.SendEdit,'String');
strfinal=strcat(str,blanks(1),'//');
vpx_SendCommandString(strfinal);


% --- Executes on button press in pushbutton5NewUniqueDataFile.
function pushbutton5NewUniqueDataFile_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5NewUniqueDataFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vpx_SendCommandString('dataFile_NewUnique');

% --- Executes on button press in CloseDataFile.
function CloseDataFile_Callback(hObject, eventdata, handles)
% hObject    handle to CloseDataFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vpx_SendCommandString('dataFile_Close');

% --- Executes on button press in Pause.
function Pause_Callback(hObject, eventdata, handles)
% hObject    handle to Pause (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vpx_SendCommandString('dataFile_Pause');

% --- Executes on button press in Resume.
function Resume_Callback(hObject, eventdata, handles)
% hObject    handle to Resume (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vpx_SendCommandString('dataFile_resume');


% --- Executes on button press in Buttona.
function Buttona_Callback(hObject, eventdata, handles)
% hObject    handle to Buttona (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vpx_SendCommandString('dataFile_insertmarker A');

% --- Executes on button press in ButtonE.
function ButtonE_Callback(hObject, eventdata, handles)
% hObject    handle to ButtonE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vpx_SendCommandString('dataFile_insertmarker E');

% --- Executes on button press in ButtonH.
function ButtonH_Callback(hObject, eventdata, handles)
% hObject    handle to ButtonH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vpx_SendCommandString('dataFile_insertmarker H');

% --- Executes on button press in ButtonP.
function ButtonP_Callback(hObject, eventdata, handles)
% hObject    handle to ButtonP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vpx_SendCommandString('dataFile_insertmarker P');

% --- Executes on button press in ButtonT.
function ButtonT_Callback(hObject, eventdata, handles)
% hObject    handle to ButtonT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vpx_SendCommandString('dataFile_insertmarker T');

% --- Executes on button press in ButtonL.
function ButtonL_Callback(hObject, eventdata, handles)
% hObject    handle to ButtonL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vpx_SendCommandString('dataFile_insertmarker L');


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global openingFcn
global flag

if(openingFcn==1)
    % Signal the openingFcn to end and let it close the figure.
    flag = 1;
else
    % We close the figure.
    delete(hObject);
end


function edt_pupil_aspect_ratio_Callback(hObject, eventdata, handles)
% hObject    handle to edt_pupil_aspect_ratio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_pupil_aspect_ratio as text
%        str2double(get(hObject,'String')) returns contents of edt_pupil_aspect_ratio as a double


% --- Executes during object creation, after setting all properties.
function edt_pupil_aspect_ratio_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_pupil_aspect_ratio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edt_pupil_width_Callback(hObject, eventdata, handles)
% hObject    handle to edt_pupil_width (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_pupil_width as text
%        str2double(get(hObject,'String')) returns contents of edt_pupil_width as a double


% --- Executes during object creation, after setting all properties.
function edt_pupil_width_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_pupil_width (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edt_pupil_height_Callback(hObject, eventdata, handles)
% hObject    handle to edt_pupil_height (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_pupil_height as text
%        str2double(get(hObject,'String')) returns contents of edt_pupil_height as a double


% --- Executes during object creation, after setting all properties.
function edt_pupil_height_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_pupil_height (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edt_x_gaze_Callback(hObject, eventdata, handles)
% hObject    handle to edt_x_gaze (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_x_gaze as text
%        str2double(get(hObject,'String')) returns contents of edt_x_gaze as a double


% --- Executes during object creation, after setting all properties.
function edt_x_gaze_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_x_gaze (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edt_y_gaze_Callback(hObject, eventdata, handles)
% hObject    handle to edt_y_gaze (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edt_y_gaze as text
%        str2double(get(hObject,'String')) returns contents of edt_y_gaze as a double


% --- Executes during object creation, after setting all properties.
function edt_y_gaze_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt_y_gaze (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_eye_a.
function btn_eye_a_Callback(hObject, eventdata, handles)
% hObject    handle to btn_eye_a (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global eye
eye = 0;

% --- Executes on button press in btn_eye_b.
function btn_eye_b_Callback(hObject, eventdata, handles)
% hObject    handle to btn_eye_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global eye
eye = 1;


function SendEdit_Callback(hObject, eventdata, handles)
% hObject    handle to SendEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SendEdit as text
%        str2double(get(hObject,'String')) returns contents of SendEdit as a double


% --- Executes during object creation, after setting all properties.
function SendEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SendEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

