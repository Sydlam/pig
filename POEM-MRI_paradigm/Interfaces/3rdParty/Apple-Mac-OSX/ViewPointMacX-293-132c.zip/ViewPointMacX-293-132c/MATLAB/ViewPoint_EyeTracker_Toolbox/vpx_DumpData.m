eyn = 0;
[xposition, yposition]=vpx_GetGazePoint(eyn)
[xposition, yposition]=vpx_GetGazePointSmoothed(eyn)