function roiHit=vpx_ROI_GetHitListItem( eyetype, roiID )
%----------------------------------------------------------------------
%% vpx_ROI_GetHitListItem
%  
%       Returns:
%           (a) the roiID number of the N'th ROI that was hit, or
%           (b) ROI_NOT_HIT = -9999 if there was no N'th box hit.
%
%
%   USAGE: 
%       roiHit=vpx_ROI_GetHitListItem( eyetype, roiID )
%   	where 
%           eyeID : 0 for Eye_A, or 1 for Eye_B
%           roiID : must be in range 0..(MAX_ROI_BOXES-1)
%
%   OUTPUT: 
%       roiHit
%           (a) the roiID number of the N'th ROI that was hit, or
%           (b) ROI_NOT_HIT = -9999 if there was no N'th box hit.
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
roiHit=calllib('vpx','VPX_ROI_GetHitListItem', eyetype, roiID );