function [drift]=vpx_GetDrift(eyetype)
%----------------------------------------------------------------------
%% vpx_GetDrift
%
%   vpx_GetDrift retrieves the total 2D vector drift
%	 for the specified eye.
%	 Units: normalized screen space.
%
%   USAGE: [drift]=vpx_GetDrift(eyetype);
%   INPUT: eyetype (0 for Eye_A and 1 for Eye_B)
%   OUTPUT: drift
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%----------------------------------------------------------------------
 driftvalue=double(0);
 if(nargin<1)
     [null,drift]=calllib('vpx','VPX_GetDrift2',0,driftvalue);  
 elseif(nargin==1)
 [null,drift]=calllib('vpx','VPX_GetDrift2',eyetype,driftvalue);
 end
