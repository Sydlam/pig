function r = vpx_GazeMovement(roicheck)
%--------------------------------------------------------------------------
%% vpx_GazeMovement
%   
%    This is a demonstration that samples the position of gaze every second 
%    and displays a white square on the screen such that it  moves on the 
%    screen with the eye.
%    Optionally, the demo can be set to check whether the gaze point is 
%    within a region of interest (ROI) and change the color of the square 
%    (to green) if it is.
%    Note 1: Currently only monocular.  
%    Note 2: Requires that calibration has been performed.
%
%    USAGE : vpx_GazeMovement OR vpx_GazeMovement(roicheck)
%    Input: roicheck (roicheck=1 when you want to check whether the gaze point is 
%    within a region of interest (ROI)
%
%    TO HALT/EXIT THE PROGRAM(From PsychToolbox)
%       Bring forward matlab command window and press Ctrl-C. This halts the program. 
%       (Type a "c" while holding down the "Ctrl"
%   	key.)  To halt a runaway Psychtoolbox script in
%   	Win Psychtoolbox you might resort to the Windows Task Manager to kill
%   	the Matlab process.  (Use Ctrl-Alt-Delete to open a window from which
%   	you can start the Task Manager.)
%
%   ViewPoint EyeTracker Toolbox (TM)
%   Copyright 2005-2010, Arrington Research, Inc.
%   All rights reserved.
%--------------------------------------------------------------------------

whichscreen=0; 
[window,screensize]=screen(whichscreen,'OpenWindow',[0 0 0]);
%rect=[0 0 200 200];
%window=Screen(whichScreen,'OpenWindow',[],[],pixelSize);
if(nargin<1|roicheck==0)
    for i = 1 : 300 % 5 minutes
        [x,y]=vpx_GetGazepoint();
        rect=[(x*screensize(3))-50,(y*screensize(4))-50,(x*screensize(3))+50,(y*screensize(4))+50];
        screen(window,'FillRect',[255 255 255],rect);
        screen(window,'Flip');
        WaitSecs(1);
        screen(window,'FillRect',[0 0 0]);
        screen(window,'Flip');
    end
elseif(nargin==1|roicheck==1)
    for i = 1 : 300
        hitlist=vpx_ROI_GetHitListItem(0, 0);
        [x,y]=vpx_GetGazePoint();
        rect=[(x*screensize(3))-50,(y*screensize(4))-50,(x*screensize(3))+50,(y*screensize(4))+50];
        if(hitlist<0)
            screen(window,'FillRect',[255 255 255],rect);
        else
            screen(window,'FillRect',[0 255 0],rect);
        end
        screen(window,'Flip');
        WaitSecs(1);
        screen(window,'FillRect',[0 0 0]);
        screen(window,'Flip');
    end
end
screen(window,'Close')