/*-----------------------------------------------------------------
/  vpx.h
/		ViewPoint EyeTracker (R) API for Macintosh OSX
/
/		VPX_*  functions are __cdecl
/		vpxs_* functions are __stdcall WINAPI
/
/	When importing the dynamic library into matlab, you must do:
/		#define  _IMPORTING_INTO_MATLAB
/
/	If you do NOT want to include <windows.h>, 
/	 you must do the following before calling this .h file:
/		#define  _NO_WINDOWS_
/
/
/	- DO NOT MODIFY ANYTHING BELOW !!!
/
/   	ViewPoint EyeTracker Toolbox (TM)
/   	Copyright 2005-2010, Arrington Research, Inc.
/   	All rights reserved.
/
/    Changes:
/      19-Mar-2010  kfa  2.8.5.000
/					
/--------------------------------------------------------------------*/

#ifndef VPX_DOT_H
#define VPX_DOT_H

#define VPX_SDK_VERSION		285.000

#include <stdint.h>
/*
 stdint.h is a header file in the C standard library introduced in the C99 standard library section 7.18 
 to allow programmers to write more portable code by providing a set of typedefs that specify exact-width integer types, 
 together with the defined minimum and maximum allowable values for each type, using macros. 
 */

#ifndef _UNIX_	// +UNIX:a
	#define _WIN32_
#endif			// -UNIX:a

#ifdef _WIN32_	// +MSWIN:a
	#ifndef _NO_WINDOWS_
		#include <windows.h>
	#endif
#else		// -MSWIN:a
			// +UNIX:b
	#include <sys/time.h>
	
	// Data types that need to be defined for non-Windows platforms
	typedef int LPARAM;
	typedef unsigned int WPARAM;
	#ifdef UNICODE
		typedef WCHAR TCHAR;
	#else
		typedef char TCHAR;
	#endif

	//--------------------------------------------------------------

	typedef struct
	{
		int	x;
		int	y;
	} POINT;
	
	//--------------------------------------------------------------
	typedef struct
	{
		int	left;
		int	top;
		int	right;
		int	bottom;
	} RECT;
	
	//--------------------------------------------------------------
	#define FALSE 0
	#define TRUE  1
	
	#ifdef UNICODE
	#define TEXT(quote) L##quote
	#else
	#define TEXT(quote) quote
	#endif
	
#endif		// -UNIX:b



	//--------------------------------------------------------------


// begin EXPORT / IMPORT 
#ifdef _WIN32_
	#ifdef _EXPORTING
	#define VPX_DECLSPEC    __declspec(dllexport)
	#else
	#define VPX_DECLSPEC    __declspec(dllimport)
	#endif
#else
	#define VPX_DECLSPEC
#endif
// end EXPORT / IMPORT 

#ifdef _WIN32_
	#define CALLCONV  __cdecl
#else
	#define CALLCONV
#endif
#define int_				VPX_DECLSPEC int32_t CALLCONV
#define long_				VPX_DECLSPEC int32_t CALLCONV
#define double_				VPX_DECLSPEC double CALLCONV
#define void_				VPX_DECLSPEC void CALLCONV
#define VPX_EyeEventType_	VPX_DECLSPEC VPX_EyeEventType CALLCONV
#define POINT_				VPX_DECLSPEC POINT CALLCONV
#define HWND_				VPX_DECLSPEC HWND CALLCONV

/**-----------------------------------------------------------------
/						VIEWPOINT PROGRAM CONSTANTS
/--------------------------------------------------------------------*/

#define tenK 10000
#define MAX_ROI_BOXES	100
#define MAX_ROI_DISPLAY  10 // shows in real-time display, also max for isoeccentric
#define ROI_NOT_HIT   -9999 // modified 2.8.3.27 for roiEvents (+/-), was: -1
#define ROI_NO_EVENT  -9999 // may be changed to zero.

#define EYE_A 0
#define EYE_B 1
#define VPX_EyeType int
#define SCENE_A		2
#define SCENE_B		3

/**-----------------------------------------------------------------
/						Data Quality Codes
/--------------------------------------------------------------------*/
#define VPX_DataQuality					int
#define VPX_QUALITY_PupilScanFailed		5	// pupil scan threshold failed.
#define VPX_QUALITY_PupilFitFailed		4	// pupil could not be fit with an ellipse.
#define VPX_QUALITY_PupilCriteriaFailed	3	// pupil was bad because it exceeded criteria limits.
#define VPX_QUALITY_PupilFallBack		2	// wanted glint, but it was bad, using the good pupil.
#define VPX_QUALITY_PupilOnlyIsGood		1	// wanted only the pupil and got a good one.
#define VPX_QUALITY_GlintIsGood			0	// glint and pupil are good.


/**-----------------------------------------------------------------
/						DLL Distributor Connection
/--------------------------------------------------------------------*/
#define VPX_DistributorType					int
#define VPX_Distributor_None				0
#define VPX_Distributor_IsViewPoint			1
#define VPX_Distributor_IsRemoteLink		2
#define VPX_Distributor_IsEtherClient		3

/**-----------------------------------------------------------------
/						Status Items
/--------------------------------------------------------------------*/
typedef enum {
	VPX_STATUS_HEAD                     = 0,
	VPX_STATUS_ViewPointIsRunning       = 1, // returns bool, if true, it may be running on remote machine
	VPX_STATUS_VideoIsFrozen            = 2, // returns bool	
	VPX_STATUS_DataFileIsOpen           = 3, // returns bool 
	VPX_STATUS_DataFileIsPaused         = 4, // returns bool	
	VPX_STATUS_AutoThresholdInProgress  = 5, // returns bool 
	VPX_STATUS_CalibrationInProgress    = 6, // returns bool 
	VPX_STATUS_StimulusImageShape       = 7, // returns 'I'=isotropic stretch, 'C'=centered, 'F'=fit to window, 'A'=actual
	VPX_STATUS_BinocularModeActive      = 8, // returns bool
	VPX_STATUS_SceneVideoActive         = 9, // returns bool
	VPX_STATUS_DistributorAttached      =10, // returns 0=None, 1=ViewPoint, 2=RemoteLink, what is connected to this local DLL
	VPX_STATUS_CalibrationPoints        =11, // returns the number of calibrtion points: 6,9,12,...,72
	VPX_STATUS_TTL_InValues             =12, // TENTATIVE :: bit code for ttl hardware input channels
	VPX_STATUS_TTL_OutValues            =13, // TENTATIVE :: bit code for ttl hardware output channels
	VPX_STATUS_TAIL
} VPX_StatusItem; // Use with: VPX_GetStatus, eg. after VPX_STATUS_CHANGE notification


/**-----------------------------------------------------------------
/						VPX_EyeEventType
/--------------------------------------------------------------------*/
typedef enum 
{
	VPX_EVENT_HEAD                     = 0,
	VPX_EVENT_NoEvent                  = 1,
	VPX_EVENT_Fixation_Start           = 2,
	VPX_EVENT_Fixation_Continue        = 3,
	VPX_EVENT_Fixation_Stop            = 4,
	VPX_EVENT_Drift_Start              = 5,
	VPX_EVENT_Drift_Continue           = 6,
	VPX_EVENT_Drift_Stop               = 7,
	VPX_EVENT_Saccade_Start            = 8,
	VPX_EVENT_Saccade_Continue         = 9,
	VPX_EVENT_Saccade_Stop             =10,
	VPX_EVENT_Blink_Start              =11,
	VPX_EVENT_Blink_Continue           =12,
	VPX_EVENT_Blink_Stop               =13,
	VPX_EVENT_NoBlink                  =14,
	VPX_EVENT_TAIL
} VPX_EyeEventType; // unifies VP EyeEventType & VPX_DataEventType


/**-----------------------------------------------------------------
/						PRECISION TIMING
/	VPX_GetPrecisionDeltaTime( double *inStartTime, BOOL setStartTime )
/--------------------------------------------------------------------*/
#define SINCE_PRECISE_INIT_TIME   ((double*)NULL)
	// May be used instead of *inStartTime; when NULL is passed to
	// VPX_GetPrecisionDeltaTime it will return the time since the
	// functions was first initiliazed, which is when it was first called.
	// E.g.: VPX_GetPrecisionDeltaTime(SINCE_PRECISE_INIT_TIME,LEAVE_PRECISE_HOLD_TIME);

#define RESET_PRECISE_HOLD_TIME	1
#define LEAVE_PRECISE_HOLD_TIME	0
	// May be used to more clearly specify whether the *inStartTime parameter
	// variable is to be updated with the current time, for use next time, or left unchanged. 
	// E.g.: VPX_GetPrecisionDeltaTime(&lastGetTimeValue,RESET_PRECISE_HOLD_TIME);

#define PRECISE_TIME_UNAVAILABLE	-3.0 
#define PRECISE_TIME_INITIALIZING	-4.0 
	// Special return values. 
	// PRECISE_TIME_INITIALIZING is returned the firt time 
	//	that the function is called, that is, there is no delta time yet.
	// PRECISE_TIME_UNAVAILABLE is returned if the hardware does not support
	//	precision timing.
	// E.g.: if ( PRECISE_TIME_UNAVAILABLE == VPX_GetPrecisionDeltaTime(NULL,0) reportProblem();


/**-----------------------------------------------------------------
/			NOTIFICATION CODES for vp_message WindowsMessage
/--------------------------------------------------------------------*/
typedef enum {
	VPX_ENUM_NOTIFICATIONS_HEAD	= 0,
	
	VPX_Obsolete_01             = 1,
	
	VPX_DAT_FRESH               = 2,   // there is fresh data available
	
	VPX_Obsolete_03             = 3,
	VPX_Obsolete_04             = 4,
	
	VPX_CAL_WARN                = 5,   // Added vp.2.8.1.12 , temporally follows VPX_CAL_BEGIN notifies subject "GET READY"
	VPX_CAL_BEGIN               = 6,   // begin calibration sequence
	VPX_CAL_SHOW                = 7,   // index, 	(y,x)
	VPX_CAL_ZOOM                = 8,   // radius, 	(y,x)
	VPX_CAL_SNAP                = 9,   // index, 	(y,x)
	VPX_CAL_HIDE                =10,   // index, 	(y,x)
	VPX_CAL_END                 =11,   // end calibration sequence, doingSlipFix=LOWORD
	VPX_CAL_TAIL                =12,

	VPX_ROI_CHANGE              =13,   // Region Of Interest (ROI) was changed somewhere

	VPX_Obsolete_14             =14,
	VPX_Obsolete_15             =15,
	VPX_Obsolete_16             =16,
	VPX_Obsolete_17             =17,
	VPX_Obsolete_18             =18,
	VPX_Obsolete_19             =19,

	VPX_COMMAND_STRING          =20,
	VPX_STATUS_CHANGE           =21,
	
	VPX_Obsolete_22             =22,
	VPX_Obsolete_23             =23,
	VPX_Obsolete_24             =24,

	VPX_VIDEO_FrameAvailable    =25,
	VPX_TRIGGER_EVENT           =26,
	VPX_VIDEO_SyncSignal        =27,
	
	VPX_Private_164             =164,
	VPX_Private_165             =165,

	VPX_ENUM_NOTIFICATIONS_TAIL
	
} VP_Message_NotificationCodes;


/**-----------------------------------------------------------------
/						ENUMS
/--------------------------------------------------------------------*/

typedef enum { 
	VPX_PARSE_HEAD=0, 					// 0 should never occur
	VPX_PARSE_OK,						// 1 indiates OK : New 2.8.1.009, was (PARSE_COMMENT)
	VPX_PARSE_ACTION, 					// 2 indicates immedate return
	VPX_PARSE_END, 						// 3 ( result <= VPX_PARSE_END ) ? "OK" : "ERROR"
	VPX_PARSE_COMMENT,					// 4 <- INSERTED, moved from VPX_PARSE_OK location 2.8.1.009
	VPX_PARSE_ERROR_HEAD,				// error = ( result > VPX_PARSE_ERROR_HEAD )
	VPX_PARSE_ERROR_UnknownCommand, 
	VPX_PARSE_ERROR_MissingParameter, 
	VPX_PARSE_ERROR_EmptyLine, 			// new 2.7.0.090
	VPX_PARSE_ERROR_SendMessageTimeOut, // send from: VPX_SendCommand
	VPX_PARSE_ERROR_IllegalParameter, 	// send from: parser
	VPX_PARSE_ERROR_ParserIsNotRunning, // send from: VPX_SendCommand if ViewPoint is not running
	VPX_PARSE_TAIL 
} VPX_ParseType;
	/*
		NOTE:
			The above VPX_ParseType enums refer to success or failure of the parsing operation.
		If the successfull parsing causes another operation to be performed,
		then the the return value from that operation may be returned.
		For example, VPX_SendCommand("updateData") should parse OK, but the
		requested operation may subsequently fail, so a useful error code is
		send back.
			The return values for parse are all positive integers.
			The return values for subsequent operations should all be negative.
	*/ 

typedef enum {
	VPX_CALLBACK_HEAD,
	VPX_CALLBACK_INSERTED,
	VPX_CALLBACK_INSERT_DUPLICATE,
	VPX_CALLBACK_LIST_LENGTH_EXCEEDED,
	VPX_CALLBACK_INSERT_ERROR,
	VPX_CALLBACK_REMOVED,
	VPX_CALLBACK_NOT_FOUND,
	VPX_CALLBACK_LIST_IS_EMPTY,
	VPX_CALLBACK_REMOVE_ERROR,
	VPX_CALLBACK_TAIL
} VPX_CallbackResult;
	/*
		The return value for: 
			VPX_InsertMessageRequest
			VPX_RemoveMessageRequest
	*/
		


/**-----------------------------------------------------------------
/						TYPEDEFS
/--------------------------------------------------------------------*/

typedef float VPX_RealType ;
	// changing this to double will have broad effects, including: sscanf(s,"%g",&df);

typedef struct {
	VPX_RealType  x ;
	VPX_RealType  y ;
} VPX_RealPoint ;

typedef struct {
	VPX_RealType  left ;
	VPX_RealType  top ;
	VPX_RealType  right ;
	VPX_RealType  bottom ;
} VPX_RealRect ;

typedef struct {
	VPX_RealType  x ;		// horizontal-axis
	VPX_RealType  y ;		// vertical-axis
	VPX_RealType  z ;		// depth-axis
	VPX_RealType  roll ;	// about the z-axis (vertical-axis)
	VPX_RealType  pitch ;	// about the x-axis (horizontal-axis)
	VPX_RealType  yaw ;		// about the y-axis (depth-axis)
} VPX_PositionAngle ;

typedef struct
{
	unsigned int		msgval;
	unsigned int		wp;
	int					lp;
	uint64_t			event;
} VPX_Message;

typedef void (*vpx_callback_t)(unsigned int);

/**-------------------------------------------------------------------
/						PROTOTYPES
/
/	Linux/Mac OS X entry/exit functions
/		Initialize Library
/		Get Version
/
/	EyeTracker Control
/		Send Command String
/
/	EyeTracker Data Functions 
/		(d) eye tracker data
/			 eyeSpace data, raw data
/			 gazeSpace data, computed data
/			 other eye data: quality, velocities, fixation duration, drift duration, torsion
/			 eye event functions
/		(t) timeStamps and deltaTime for
/
/	External Data Functions (asynchronous update)
/		(c) CursorPosition, mouse location on local machine
/		(h) HeadPositionAngle, external head tracker hardware
/
/	ViewPoint Parameter Functions
/		(k) Status
/		(m) Display Measures: VPX_GetMeasuredScreenSize, VPX_GetMeasuredViewingDistance
/		(r) ROI functions
/		(c) Calibration
/
/	Programming Functions
/		(a) Application functions: LaunchApp, AppCount
/		(e) Event notification message functions
/		(v) DLL / SDK version checking functions
/		(w) HWND functions, StimulusWindow, GazeSpaceWindow, RemoteWindows
/		(u) Utility functions, drawing, conversion, etc.
/
/--------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

#ifdef _UNIX_
/**---------------------------------------------------------------------
* Unix Function Prototypes - for Linux and Mac OS X applications only
----------------------------------------------------------------------*/

/**------------------------------------------------------------------------
 * This function initializes the shared object. It must be called before any
 *  other calls are made. A zero is returned upon success, -1 on failure. If
 * the call fails errno will be set and a cause will usually be printed to 
 * stderr.
 -------------------------------------------------------------------------*/
int_ VPX_so_init();
	
/**-------------------------------------------------------------------------
* This function returns the version of the vpx_interapp shared library
--------------------------------------------------------------------------*/
double_ VPX_GetVersion();
#endif
/**--------------------------------------------------------------------------
* End of UNIX-specific functions
---------------------------------------------------------------------------*/

	/*-------------------------------------------------------------------------------
	 /						VPX_ConnectToViewPoint
	 /		example:
	 /			ret = VPX_ConnectToViewPoint( "192.168.1.4",5000);
	 /			returns: 0 = connected ok, -1 = generic fail
	 /-------------------------------------------------------------------------------*/
	int_ VPX_ConnectToViewPoint( char* ipAddress, int32_t port );
	
	/*-----------------------------------------------------------------
	 /						VPX_DisconnectFromViewPoint
	 /			returns: 0 = connected ok, -1 = generic fail
	 /--------------------------------------------------------------------*/
	int_ VPX_DisconnectFromViewPoint();
	
	
///=========================================================================================
/// (d) *** Send Command String  ***
/// DLL Relevance: GLOBAL
/// ViewPointClient: YES
/// RemoteLink Access: YES
///=========================================================================================

// begin MATLAB FIX
#ifdef _IMPORTING_INTO_MATLAB
#define  VPX_SendCommand   VPX_SendCommandString
#else
	long_ VPX_SendCommand( char * szFormat, ...);
#endif
// end MATLAB FIX

#ifdef _WIN32_
int_  VPX_SendCommandString( char *cmd );
#else
int VPX_SendCommandString(const char *cmd);
#endif
	// VPX_SendCommand & VPX_SendCommandString provide a mechanism to 
	//  send CLP command strings to ViewPoint. The former allows formatted strings, like printf,
	//  the latter is provided for environments that do not support formatted strings.
	// VPX_DECLSPEC int VPX_SendCommand( TCHAR * szFormat, ...); is declared above in conditional
	// eg: result = VPX_SendCommand("dataFile_NewName rabbitPictureData");
	// eg. result = VPX_SendCommand("dataFile_InsertString \"Showing Picture of a Rabbit \" ");
	// Detail results are provided; check result against VPX_ParseType enums listed above


///=========================================================================================
/// (d) *** EYE TRACKER DATA  ***
/// DLL Relevance: GLOBAL, from ViewPoint machine.
/// ViewPointClient: YES
/// RemoteLink Access: Some
///=========================================================================================

/// *** EyeSpace Data  ***

int_  VPX_GetPupilCentroid2( VPX_EyeType eyn, VPX_RealPoint *pc );
int_  VPX_GetGlintCentroid2( VPX_EyeType eyn, VPX_RealPoint *gc );
	// VPX_GetPupilCentroid2 & VPX_GetGlintCentroid2 retrieve the 
	// raw EyeSpace locations of the centroids obtained from the threshold scans.

int_  VPX_GetPupilSize( VPX_RealPoint *ps );
int_  VPX_GetPupilSize2( VPX_EyeType eye, VPX_RealPoint *ps );
	// VPX_GetPupilSize retrieves the size of the oval fit to the pupil
	// in the EyeSpace window.  NOTE: The x- y-size values are normalized
	// with respect to the EyeSpace dimensions that have a 4:3 aspect, so
	// the x- and y-values are anisotropic.  To obtain the aspect ratio of
	// the pupil, rescale by:  ( aspect = ps.x / ( ps.y * 0.75 ) ).

int_  VPX_GetPupilPoint( VPX_RealPoint *pp );
int_  VPX_GetPupilPoint2( VPX_EyeType eye, VPX_RealPoint *pp );
	// VPX_GetPupilPoint retrieves the normalized (x,y) location of the 
	// center of the pupil (center of the oval fit to the pupil) in the EyeSpace.

int_  VPX_GetGlintPoint( VPX_RealPoint *gp );
int_  VPX_GetGlintPoint2( VPX_EyeType eye, VPX_RealPoint *gp );
	// VPX_GetGlintPoint retrieves the normalized (x,y) location of the 
	// center of the glint (center of the oval fit to the glint) in the EyeSpace.

int_  VPX_GetDiffVector( VPX_RealPoint *dv);
int_  VPX_GetDiffVector2( VPX_EyeType eye, VPX_RealPoint *dv );
	// VPX_GetDiffVector retrieves the normalized vector difference between
	// the centers of the pupil and the glint in the EyeSpace.

int_  VPX_GetPupilOvalRect( VPX_RealRect *ovr);
int_  VPX_GetPupilOvalRect2( VPX_EyeType eye, VPX_RealRect *ovr );
	// VPX_GetPupilOvalRect retrieves the normalized rectangle coordinates
	// that specify the flat ellipse (oval) fit to the pupil.
	// Note: rotated ellipse fitting requires more values to be specified - FUTURE

int_  VPX_GetPupilAspectRatio( double *ar );
int_  VPX_GetPupilAspectRatio2( VPX_EyeType eye, double *ar );
	// VPX_GetPupilAspectRatio is independent of the EyeCamera window shape.
	// aspect ratio, so a circular pupil will always produce a value of 1.0
	// values are swapped so numberator is always less than denominator, so value always in range {0.0 1.0}
// Note: with oval fit this is horizontal:vertical extrema; with ellipse filt it is major:minor axis

/// *** GazeSpace Data ***

int_  VPX_GetGazePoint( VPX_RealPoint *gp );
int_  VPX_GetGazePoint2( VPX_EyeType eye, VPX_RealPoint *gp );
int_  VPX_GetGazePointSmoothed2( VPX_EyeType eye, VPX_RealPoint *gp );
#define VPX_GetGazePointSmoothed(p) VPX_GetGazePointSmoothed2( EYE_A, p )
	// VPX_GetGazePoint retrieves the calculated position of gaze.
int_  VPX_GetGazeAngle2( VPX_EyeType eye, VPX_RealPoint *gp );
int_  VPX_GetGazeAngleSmoothed2( VPX_EyeType eye, VPX_RealPoint *gp );
	// VPX_GetGazeAngle* functions use the measured Geometry values set by the user
	// via the GeometryGrid window in the ViewPoint application.
	// To access these values use: VPX_GetMeasuredScreenSize and VPX_GetMeasuredViewingDistance

/// *** Other Eye Data  ***

int_  VPX_GetDataQuality2( VPX_EyeType eyn, VPX_DataQuality *quality );
	// VPX_GetDataQuality2 retrieves a code indicating what, if any, errors
	// occurred during image processing and during testing against various
	// data criteria levels.  
	// Compare result against defined constants VPX_QUALITY_* specified above.
#define VPX_GetDataQuality(q)  VPX_GetDataQuality2( EYE_A, q )

int_  VPX_GetTotalVelocity(double *gp);
int_  VPX_GetTotalVelocity2( VPX_EyeType eye, double *gp );
	// VPX_GetTotalVelocity retrieves the total velocity of
	// movement in the (x,y) plane.  That is, the first derivative
	// of the (smoothed) calculated position of gaze.

int_  VPX_GetComponentVelocity(  VPX_RealPoint *gp );	
int_  VPX_GetComponentVelocity2( VPX_EyeType eye, VPX_RealPoint *gp );	
	// VPX_GetComponentVelocity retrieves the x- and y-components of the 
	// eye movement velocity, based on the (smoothed) calculated position of gaze.

int_  VPX_GetFixationSeconds2( VPX_EyeType eye, double *fs );
	// VPX_GetFixationSeconds retrieves the number of seconds that  
	// the total velocity has been below the VelocityCriterion and
	// the gaze drift has been below the DriftCriterion.
	// NOTE: A zero (0.0) value indicates a saccade is occurring.
	// Use with:
	//		VPX_SendCommand( "velocityCriterion 0.3");
	// 		VPX_SendCommand( "driftCriterion 0.1");
	//		e = VPX_GetEyeMovementEvent2( EYE_A );

int_  VPX_GetDrift2( VPX_EyeType eyn, double *drift);
	// VPX_GetDrift2 retrieves the total 2D vector drift for the specified eye.
	// Units: normalized screen space.

VPX_EyeEventType  VPX_GetBlinkEvent2( VPX_EyeType eyn );
VPX_EyeEventType  VPX_GetEyeMovementEvent2( VPX_EyeType eyn );

int_  VPX_GetTorsion(double *degrees);
int_  VPX_GetTorsion2( VPX_EyeType eye, double *degrees );
	// Torsion is in +/- degrees (e.g.: 2.25 degrees rotation along the line of sight)

/// *** Eye Event Data  ***

VPX_EyeEventType_  VPX_GetBlinkEvent2( VPX_EyeType eyn ); // new 2.8.3.26
	// Returns one of: NoBlink, Blink_Start, Blink_Continue, Blink_Stop currentl event status.

VPX_EyeEventType_  VPX_GetEyeMovementEvent2( VPX_EyeType eyn ); // new 2.8.3.26
	// Returns one of: Saccade_Start/Continue, Fixation_Start/Continue, Drift_Start/Continue
	// Never returns Saccade/Fixation/Drift_Stop


///=========================================================================================
/// (t) *** TimeStamps and DeltaTime of Data ***
/// DLL Relevance: GLOBAL, from VPX_GetPrecisionDeltaTime on ViewPoint machine.
/// ViewPointClient: YES
/// RemoteLink Access: ??
///=========================================================================================

int_  VPX_GetDataTime2( VPX_EyeType eyn, double *seconds);
#define VPX_GetDataTime(pd)  VPX_GetDataTime2( EYE_A, seconds ); // added v.2.7.1.13
	// MODIFIED in version 2.8.2.36; was data storage time, now video sych time
	// this better reflects the actual time that the image of the eye became
	// available, and is not affected by variance in image processing time.
	// NOTE: This modification effects VPX_GetDataDeltaTime2 (variance should be less).
	// Retrieves double floating point, high precision time, in seconds

int_  VPX_GetDataDeltaTime2( VPX_EyeType eyn, double *delta );
#define VPX_GetDataDeltaTime(pd)  VPX_GetDataDeltaTime2( EYE_A, pd );	// added v.2.7.1.13
	// The precision time value difference between current and previous
	// VPX_GetDataTime2 values.
	// NOTE: This is affected by a change in VPX_GetDataTime2 such that the variance
	// of the delta times should be much less.

int_  VPX_GetStoreTime2( VPX_EyeType eyn, double *tm);		// added: v.2.8.2.36
	// This is the time that the data was stored to the DLL and the
	// last VPX_DAT_FRESH event was generated.
	// Use VPX_GetDataTime for eye movement times;
	// Use this to calculate delays inter-application notification timing
	
int_  VPX_GetStoreDeltaTime2( VPX_EyeType eyn, double *tm);


///=======================================================================================


/**-------------------------------------------------------------------------------------
/	(h) VPX_SetHeadPositionAngle
/		This provides and interface for head position and angle measuring
/		devices (or emulators) to send their 6DOF values to the ViewPoint EyeTracker.
/
/ NotificationMessage: VPX_ASYNCH_HeadTracker // not yet implemented
/ DLL Relevance: GLOBAL
/ ViewPointClient: YES
/ RemoteLink: NO
/--------------------------------------------------------------------------------------*/
int_  VPX_SetHeadPositionAngle( VPX_PositionAngle pa );
	// CAUTION: there is nothing to check for multiple, conflicting input sources!

int_  VPX_GetHeadPositionAngle( VPX_PositionAngle *pa );
	// VPX_GetHeadPositionAngle retrieves the 6DOF (x,y,z,roll,pitch,yaw) data values.

/*
// NOT YET IMPLEMENTED
int_  VPX_GetInTTL();
int_  VPX_GetOutTTL();

// all return the number of bytes that are allocated, set, gotten, freed
// allocate returns zero if dataId number is already in use.
#define VPX_OtherData_TTL_IN	1
#define VPX_OtherData_TTL_OUT	2
#define VPX_OtherData_MAX		9
int_  VPX_AllocateOtherDataSpace( uint dataId, uint size );	
int_  VPX_SetOtherData( uint dataId, void* data );	
int_  VPX_GetOtherData( uint dataId, void* data );
int_  VPX_FreeOtherDataSpace( uint dataId, uint size );
*/

///=======================================================================================

/**-------------------------------------------------------------------------------------
/					ViewPoint Parameter Functions
/
/		Access to ROI, Geometry, etc.
/--------------------------------------------------------------------------------------*/

int_  VPX_GetStatus( VPX_StatusItem statusRequest );
	// The VPX_StatusItem enums are listed above at the top of this file.
	// DLL Relevance: MIXED USE

///=========================================================================================
/// (m) *** Display Measures Data ***
/// ViewPointClient: YES
/// RemoteLink Access: NO (perhaps in future version)
///=========================================================================================

int_  VPX_GetMeasuredScreenSize( VPX_RealPoint *screenSize );
	// VPX_GetMeasuredScreenSize provides the physical size 
	// of the display screen in millimeters, as calculated from the
	// ViewPoint GeometryGrid dialog specifications.

int_  VPX_GetMeasuredViewingDistance( VPX_RealType *viewingDistance );
	// VPX_GetMeasuredViewingDistance provides the physical distance (in millimeters)
	// of the subject's eye to the display screen, as specified by the user in the
	// ViewPoint GeometryGrid dialog.  NOTE: with a headTracker use: VPX_GetHeadPositionAngle

///=========================================================================================
/// (r) *** ROI - Region of Interest ***
/// DLL Relative : GLOBAL
/// ViewPointClient: YES
/// RemoteLink Access: YES (except where noted)
///=========================================================================================

int_  VPX_GetROI_RealRect(int n, VPX_RealRect *rr );

/* Windows only */
#ifdef _WIN32_ && !_IMPORTING_INTO_MATLAB
int_  VPX_drawROI( HWND hWnd, int activeRegion ); 
	// VPX_drawROI draws the activeRegion ROI in red, 
	// and draws all the other ROI in blue.
#endif

int_  VPX_ROI_GetHitListLength( VPX_EyeType eyn );
	// VPX_ROI_GetHitListLength returns a the number of ROI that are currently active, since
	// ROI can be overlapped, so more than one can be active at the same time.
	// This value is NOT cumulative over time.

int_  VPX_ROI_GetHitListItem( VPX_EyeType eyn, int NthHit );
	// VPX_ROI_GetHitListItem returns 
	//  (a) the ID number of the N'th (ordial from a list) ROI  that was hit, or
	//  (b) ROI_NOT_HIT if there was no N'th box hit.
	// NOTE: Parameter N must be in range 0..(MAX_ROI_BOXES-1)
	// An roi number indicates that the gazePoint is currently inside (either newly & previously ) that roi.

int_  VPX_ROI_GetEventListItem( VPX_EyeType eyn, int NthEvent );
	// Added 2.8.3.27 to allow access to nowEnteringRoi events
	// An positive roi number indicates that the gazePoint has newly entered that roi.
	// An negative roi number indicates that the gazePoint has just exited that roi.
	// The value ROI_NO_EVENT indicates no (no more) roi events.
	// RemoteLink Access: NO, possible future
	
///=========================================================================================
/// (c) *** Calibration ***
/// DLL Relative : GLOBAL
/// ViewPointClient: YES
/// RemoteLink Access: NO, possible future
///=========================================================================================

int_  VPX_GetCalibrationStimulusPoint( int ixPt, VPX_RealPoint *calPt );
	//		Returns 0 if successful, non-zero if ixPt is out of range {1..72}
	//		calPt is the (x,y) coordinate in normalized (0.0 .. 1.0) form.
	//		New: version 2.8.2.086


///=========================================================================================
/// *** Time ***
/// DLL Relative : LOCAL
///=========================================================================================
int_  VPX_IsPrecisionDeltaTimeAvailableQ();
	// Returns TRUE if the system supports precision time, otherwise returns false.

double_  VPX_GetPrecisionDeltaTime( double *inHoldTime, int resetHoldTime );
	// Returns  time in SECONDS since *inHoldTime, or if NULL, since DLL initialization.
	// Returns  PDT_UNAVAILABLE   if the HighPerformanceCounter is NOT AVAILABLE.
	// Returns  PDT_INITIALIZING  the first time, indicating initialization variables
	// This function may be used for many local delta time calculations by keeping
	// local inHoldTime values; this function will automatically update the inHoldTime
	// with the current time, for use next call, if resetHoldTime is true.
	// defined:  RESET_PRECISE_HOLD_TIME  1
	// defined:  LEAVE_PRECISE_HOLD_TIME  0

#define VPX_GetViewPointSeconds VPX_GetPrecisionDeltaTime(SINCE_PRECISE_INIT_TIME,LEAVE_PRECISE_HOLD_TIME)
	// Misnomer, better called VPX_GetDllSeconds.


///=========================================================================================
///
///							*** Programming Functions ***
///
///=========================================================================================

///=========================================================================================
/// (a) *** DLL only application functions ***
/// ViewPointClient: NO
/// RemoteLink Access: NO
///=========================================================================================
/* Windows only */
#ifdef _WIN32_
int_  VPX_LaunchApp( PTCHAR appNameArg, PTCHAR cmdLineArg );
	// VPX_LaunchApp launches an executable file located inside the ViewPoint Directory.
	// eg: a layered application could call: 		
	//		ok = VPX_LaunchApp( "ViewPoint.exe", "-minimized" );
	//		Sleep(1200); // Give it a chance to get started, before using: VPX_SendCommand
	//		while ( !VPX_GetStatus(VPX_STATUS_ViewPointIsRunning) ) write("."); // this usage may change!
	//
	// VPX_LaunchApp is equivalent to using the Windows
	// Start > Run... dialog box and launching ViewPoint with
	// command line flags specified, e.g.:
	// Run: "ViewPoint.exe" -freeEyeCamera -hideMain
	//
	// WARNING: If ViewPoint was launched using flags "-freeEyeCamera -hideMain", 
	// simply closing the EyeCamera window does not stop the ViewPoint process, 
	// it continues running until VPX_SendCommand("QuitViewPoint") is sent.
	//
	// RemoteLink Access: No effect.
#endif

int_  VPX_GetViewPointAppCount(int *apps);
	// VPX_GetViewPointAppCount sets apps to non-zero if ViewPoint is running.
	// Historically used in various ways including detection of use for EYE_B.
	// RemoteLink Access: Undefined return value.


///=========================================================================================
/// (v) *** SDK / DLL VERSION ***
/// DLL Relevance: LOCAL DLL ONLY
/// ViewPointClient: YES, The client checks sdk/dll verions with server upon connection.
/// RemoteLink Access: NO
///=========================================================================================

int_  VPX_VersionMismatch( double version );
	// The progarm should check for a possible mismatch between the 
	// version of the DLL that is being linked into the progarm, and the
	// version of the SDK library and function prototypes that were 
	// compiled into the application.
	// Usage: BOOL versionMismatch = VPX_VersionMismatch(VPX_SDK_VERSION);
	// Returns zero if no mismatch, returns non-zero if a version mismatch. 

double_  VPX_GetDLLVersion();
	// Usage: dllVersion = VPX_GetDLLVersion();
	// VPX_GetDLLVersion provides the version number of the dll 
	// that has been loaded at runtime.

double_  VPX_GetRevisionNumber();
	// Small revisions to DLL, mostly used for DLL development

///=========================================================================================
/// (w) *** HWND functions ***
/// DLL Relevance: ONLY for LOCAL DLL that is connected to the ViewPoint application.
/// ViewPointClient: NO
/// RemoteLink Access: NO
///=========================================================================================

/// *** EyeCamera Image functions ***
/* Windows only */
#ifdef _WIN32_ && !_IMPORTING_INTO_MATLAB
	
int_  VPX_SetEyeImageWindow( VPX_EyeType eyn, HWND hWnd );
	// VPX_SetEyeImageWindow specifies window in a layered app
	// that should be used for display of the EyeCamera image.

int_  VPX_SetEyeImageDisplayRect( VPX_EyeType eyn, RECT displayRect );
	// VPX_SetEyeImageDisplayRect allows optional re-adjustment of
	// of the display image offset and size, from the default.
	// NOTE: 320x240 provides optimal performance, other sizes may increase CPU usage.

int_  VPX_SetEyeImageOverlays( VPX_EyeType eyn, int overlayFlag );
	// Controls the display of (i) scan rects, mode text, pupil fit, etc. in the remote video image. 
	// Currenlt the overlayFlag is only taken as a boolean.

int_  VPX_SetExternalStimulusWindow( HWND hWnd );
	// VPX_SetExternalStimulusWindow specifies window in a layered app
	// that wants automatic display of calibration points, ...

/// *** Stimulus / GazeSpace HWND functions ***

HWND_  VPX_GetViewPointStimulusWindow(void);
HWND_  VPX_GetViewPointGazeSpaceWindow(void);
	// VPX_GetViewPointStimulusWindow provides the handle to ViewPoint's Stimulus_Window

#endif


///=========================================================================================
/// (u) *** Utility functions ***
/// DLL Relevance: LOCAL DLL ONLY
/// ViewPointClient: irrelevant
/// RemoteLink Access: irrelevant
///=========================================================================================

/// *** DEBUGGING ***

int_  VPX_DebugSDK(int onOff);
	// Includes:
	//	VPX_LaunchApp into verbose mode.
	//  VPX_SendCommandString - MessageBox reports any subsequent command processing errors.
	//		here, subsequent mean "after correct parsing"

/// *** DRAWING UTILITIES *** Windows only
#ifdef _WIN32_ && !_IMPORTING_INTO_MATLAB
int_  VPX_RectFrame(HDC hdc, int x1, int y1, int x2, int y2, int t);
	// RectFrame draws a hollow rectangle in the specified window.

int_  VPX_EllipseFrame(HDC hdc, int x1, int y1, int x2, int y2, int t);
	// EllipseFrame draws a hollow ellipse in the specified window.
#endif

/// *** CONVERSION UTILITIES ***

int_  VPX_WindowRECT2RealRect( RECT nr, RECT clientRect, VPX_RealRect * rr );
	// Takes in integer coordinates for a rectangle within a specified window
	// and returns the normalized coordinates for that rectangle.

int_  VPX_RealRect2WindowRECT( VPX_RealRect rr, RECT clientRect, RECT * scaledRect );
	// Takes normalized coordinates for a rectangle and returns integer coordinates
	// that have been scaled for the size of the specified window.  For example:	
	//   VPX_RealRect rr = { 0.1, 0.1, 0.2, 0,2 }; 
	//   RECT clientWindowRect = { 320, 240 };
	//   RECT scaledRect ; 
	//   VPX_RealRect2WindowRECT( rr, clientWindowRect, &scaledRect );
	//   // scaledRect will now contain { 32, 24, 64, 48 }

#ifdef __cplusplus
}
#endif

#define LOWORD(l) ((uint16_t)((uint32_t)(l)&0xffff))
#define HIWORD(l) ((uint16_t)((uint32_t)(l)>>16))
#define PointInRectQ(pt,rr) ( ( pt.x < rr.right ) && ( pt.y < rr.bottom ) && ( rr.left < pt.x ) && ( rr.top < pt.y ) )

/*====================  begin: maybe keep in dylib, but not here =======================

#define PointInRectQ(pt,rr) ( ( pt.x < rr.right ) && ( pt.y < rr.bottom ) && ( rr.left < pt.x ) && ( rr.top < pt.y ) )
	// PointInRectQ will work with points and rectangles of either IntegerType or RealType
	// However, be careful not to mix normalized arguments with screen coordinate based arguments.

 ====================  end: maybe keep in dylib, but not here =======================*/ 


/*====================  begin: OBSOLETE =======================
 
 #define MAKELONG(a,b) ((int32_t)(((uint16_t)((uint32_t)(a)&0xffff))|((uint32_t)((uint16_t)((uint32_t)(b)&0xffff)))<<16))
 
 #define LOWORD(l) ((uint16_t)((uint32_t)(l)&0xffff))
 #define HIWORD(l) ((uint16_t)((uint32_t)(l)>>16))
 
 #define VPX_MESSAGE "VPX_message"
 // used to RegisterWindowMessage(VPX_MESSAGE)
 // If two different applications register the same message string, 
 // the applications return the same message value. 
 // The message remains registered until the session ends. 
 
 #define NOBLOCK 1

 
 ///=========================================================================================
 /// (e) *** DLL NOTIFICATION MESSAGING ***
 /// DLL Relevance: LOCAL DLL ONLY
 /// ViewPointClient: irrelevant
 /// RemoteLink Access: irrelevant
 ///=========================================================================================
 #ifdef _WIN32_
 int_  VPX_InsertMessageRequest(HWND hWnd, UINT msg );
 #else
 int VPX_InsertMessageRequest(unsigned int msg);
 #endif
 // VPX_InsertMessageRequest installs the specified hWnd into the list 
 // of windows that are sent notification messages whenever fresh data 
 // is available,or some other important information becomes available.
 // Usage: 
 //		const static UINT wm_VPX_message = RegisterWindowMessage (VPX_MESSAGE);
 //		int result = VPX_InsertMessageRequest ( m_hWnd, wm_VPX_message );
 //		// MUST cleanup with VPX_RemoveMessageRequest before exiting!
 // Returns: VPX_CallbackResult as of version 2.7.1.1
 #ifdef _WIN32_
 int_  VPX_RemoveMessageRequest(HWND hWnd );
 #else
 int VPX_RemoveMessageRequest();
 #endif
 // Removes an HWND from the notification list.
 // Returns: VPX_CallbackResult as of version 2.7.1.1
 
 #ifdef _UNIX_
 int32_t VPX_GetMessages(VPX_Message *message, uint64_t msgtypes, int options, struct timeval *timeout);
 #endif
 
 int_  VPX_GetMessageListLength( int * num );
 // VPX_GetMessageListLength provides the number of HWND
 // that have requested notification.
 
 int_  VPX_GetMessagePostCount( int * num );
 // VPX_GetMessagePostCount provides a count of the number
 // of messages that have been sent.
 
 
 //----------
 
 int_  VPX_LParam2RealPoint( LPARAM codedLoc, VPX_RealPoint *pt );
 // Can be used with VPX_CAL_* messages to obtain the location of the calibration point
 // that is encoded in the message LPARAM.
 // See also: VPX_GetCalibrationStimulusPoint
 
 int_  VPX_LParam2RectPoint( LPARAM codedLoc, RECT clientRect, POINT *pt );
 // Used with VPX_CAL_* messages to obtain the location of the calibration point
 // that is encoded in the message LPARAM.
 // Takes LPARAM and and returns integer coordinates of the calibration point
 // that have been scaled for the size of the specified window.	
 // See also: VPX_GetCalibrationStimulusPoint
 
 #define VPX_ENUM_NOTIFICATIONS_HEAD_B 0x0
 #define	VPX_DAT_HEAD_B 0x1
 #define	VPX_DAT_FRESH_B 0x2
 #define	VPX_DAT_FAILED_B 0x4
 #define	VPX_DAT_TAIL_B 0x8
 #define	VPX_CAL_WARN_B 0x10
 #define	VPX_CAL_BEGIN_B 0x20
 #define	VPX_CAL_SHOW_B 0x40
 #define	VPX_CAL_ZOOM_B 0x80
 #define	VPX_CAL_SNAP_B 0x100
 #define	VPX_CAL_HIDE_B 0x200
 #define	VPX_CAL_END_B 0x400
 #define	VPX_CAL_TAIL_B 0x800
 #define	VPX_ROI_CHANGE_B 0x1000
 #define	VPX_CHANGE_PupilScanArea_B 0x2000
 #define	VPX_CHANGE_GlintScanSize_B 0x4000
 #define	VPX_CHANGE_GlintScanOffset_B 0x8000
 #define	VPX_CHANGE_GlintScanUnyokedOffset_B 0x10000
 #define	VPX_AUTOTHRESHOLD_BEGIN_B 0x20000
 #define	VPX_AUTOTHRESHOLD_END_B 0x40000
 #define	VPX_COMMAND_STRING_B 0x80000
 #define	VPX_STATUS_CHANGE_B 0x100000
 #define	VPX_DAT_EVENT_B 0x200000
 #define VPX_VPX_ENUM_NOTIFICATIONS_TAIL_B 0x400000
 #define ALL_EVENTS 0xFFFFFFFF
 
 //-------------------------------------------------------------------------------------
 //					External Data Functions (asynchronous update)
 /		This is data from external devices, e.g. TTL I/O, head trackers, etc.
 //--------------------------------------------------------------------------------------
POINT_  VPX_GetCursorPosition();
	// VPX_GetCursorPosition returns the screen coordinates of the mouse cursor.
	//
	// DLL relevance: LOCAL machine
	// RemoteLink Access: NO

 //-------------------------------------------------------------------------------
 //						VPX_SetCallbackFunction
 //		example:
 //			ret = VPX_SetCallbackFunction( myViewPiontCallbackFunction );
 //			returns: 0 = connected ok, -1 = generic fail
 //-------------------------------------------------------------------------------
	//typedef int(*VPX_CallbackFunctionType)( int event, int subEvent );
	//int VPX_SetCallbackFunction( VPX_CallbackFunctionType myCallback );


 //-------------------------------------------------------------------------------------
 //	VPX_ROI_MakeHitListString
 //		The string lists the ROI that were hit, eg: "2,45,88".
 //		If ( indicateOverflow == true ) then a "+" at the end of the string will be used
 //		to indicates that there were additional roi that could not fit in the given string.
 //		Makes a string with at most maxStringLength characters.
 //		Specifying a maxStringLength of 2 will effectively limit the reported roi to the first.
 //		For double digit numbers, prints both digits if possible, otherwise prints nothing.
 //		Does not leave dangling comma separaters.
 //
 //		If there are no roi hit, then the noHitsString is returned, eg: " -None- "
 //		The return value is the lenght of the string. 
 //--------------------------------------------------------------------------------------
 int_  VPX_ROI_MakeHitListString(VPX_EyeType		eyn,				// they eye to test for ROI hits
 char			*dataString,		// pointer to the target string
 int				maxStringLength,	// actual string length or less
 int				indicateOverflow,	// TRUE to put a '+' when overflow occurs
 char			*noHitsString		// eg: " No ROI Hit "
 );
 
 
====================  end: OBSOLETE ======================= */ 

#endif // VPX_DOT_H

