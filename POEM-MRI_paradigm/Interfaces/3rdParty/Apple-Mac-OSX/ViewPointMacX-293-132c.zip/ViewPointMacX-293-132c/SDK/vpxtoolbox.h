/*------------------------------------------------------------
 *  vpxtoolbox.h
 *  
 *
 %   ViewPoint EyeTracker Toolbox (TM)
 %   Copyright 2005-2010, Arrington Research, Inc.
 %   All rights reserved.
 *
------------------------------------------------------------*/

#define _UNIX_
#define _IMPORTING_INTO_MATLAB
#include "vpx.h"
